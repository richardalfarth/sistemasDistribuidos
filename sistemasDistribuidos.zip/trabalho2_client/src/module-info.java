module trabalho2_client {
	requires java.rmi;
}