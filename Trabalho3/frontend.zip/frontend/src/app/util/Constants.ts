export class Constants {
    static readonly DATE_FMT = 'dd/MM/yyy';
    static readonly DATE_TIM_FMT = `${Constants.DATE_FMT} hh:mm:ss`;
}