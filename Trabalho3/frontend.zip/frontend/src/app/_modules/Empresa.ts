export class Empresa {
    public id: number;
    public uf: number;
    public nomeFantasia: string;
    public cnpj: string;
}